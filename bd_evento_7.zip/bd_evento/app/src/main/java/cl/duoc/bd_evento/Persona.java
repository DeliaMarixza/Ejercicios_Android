package cl.duoc.bd_evento;

import android.os.Parcel;
import android.os.Parcelable;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class Persona{

  private int id;
  private String run;
  private String dv;
  private String nombre;
  private String fechaIngreso;

  public Persona(int id, String run, String dv, String nombre, String fechaIngreso) {
    this.id = id;
    this.run = run;
    this.dv = dv;
    this.nombre = nombre;
    this.fechaIngreso = fechaIngreso;
  }

    public Persona(String run, String dv, String nombre, String fechaIngreso) {
    this.run = run;
    this.dv = dv;
    this.nombre = nombre;
    this.fechaIngreso = fechaIngreso;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public String getRun() {
    return run;
  }

  public void setRun(String run) {
    this.run = run;
  }

  public String getDv() {
    return dv;
  }

  public void setDv(String dv) {
    this.dv = dv;
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getFechaIngreso() {
    return fechaIngreso;
  }

  public void setFechaIngreso(String fechaIngreso) {
    this.fechaIngreso = fechaIngreso;
  }

  @Override
  public String toString() {
    return "Persona{" +
            "id=" + id +
            ", run='" + run + '\'' +
            ", dv='" + dv + '\'' +
            ", nombre='" + nombre + '\'' +
            ", fechaIngreso='" + fechaIngreso + '\'' +
            '}';
  }
}


