package cl.duoc.bd_evento;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.tv.TvContentRating;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        generarLista();

        ImageView btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvRun = findViewById(R.id.tvRun);
                String run = tvRun.getText().toString();
                TextView tvDv = findViewById(R.id.tvDv);
                String dv = tvDv.getText().toString();
                TextView tvNombre = findViewById(R.id.tvNombre);
                String nombre = tvNombre.getText().toString();
                TextView tvFechaIngreso = findViewById(R.id.tvFechaIngereso);
                String fechaIngreso = tvFechaIngreso.getText().toString();
                Persona persona = new Persona(0, run,dv,nombre,fechaIngreso);

                if (!run.isEmpty()) {
                    if (!dv.isEmpty()) {
                        if (!nombre.isEmpty()) {
                            if (!fechaIngreso.isEmpty()) {
                                //SimpleDateFormat formatofecha = new SimpleDateFormat("dd-MM-yyyy");

                                CustomSql sql = new CustomSql(MainActivity.this, "miDB", null, 1);

                                if (sql.insertar(persona)) {
                                    generarLista();
                                    Toast.makeText(MainActivity.this, "Run guardado", Toast.LENGTH_LONG).show();
                                    tvRun.setText("");
                                    tvDv.setText("");
                                    tvNombre.setText("");
                                    tvFechaIngreso.setText("");
                                } else {
                                    Toast.makeText(MainActivity.this, "No guardado, complete todas las casillas", Toast.LENGTH_LONG).show();
                                }
                            } else {
                                tvFechaIngreso.setError("Debe ingresar fecha de tipo DD-MM-AAAA");
                                Toast.makeText(MainActivity.this, "No guardado, complete todas las casillas", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            tvNombre.setError("Debe ingresar un Nombre");
                            Toast.makeText(MainActivity.this, "No guardado, complete todas las casillas", Toast.LENGTH_LONG).show();
                        }
                    } else {

                        tvDv.setError("Debe ingresar Dígito Verificador del Run");
                        Toast.makeText(MainActivity.this, "No guardado, complete todas las casillas", Toast.LENGTH_LONG).show();
                    }
                } else {
                    tvRun.setError("Debe ingresar un Run");
                    Toast.makeText(MainActivity.this, "No guardado, complete todas las casillas", Toast.LENGTH_LONG).show();
                }
            }
        });

        ///// BOTON  BUSCAR  UN  REGISTRO
        ImageView btnBuscar = findViewById(R.id.btnBuscar);
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvRun = findViewById(R.id.tvRun);
                String run = tvRun.getText().toString();
                if(!run.isEmpty()) {
                    Persona persona = new Persona(0, run, "", "","");
                    CustomSql sql = new CustomSql(MainActivity.this, "miDB", null, 1);
                    sql.buscar(run);
                }
            }
        });

        ///// BOTON  UPDATE  MODIFICAR  DATOS
        ImageView btnModificar = findViewById(R.id.btnModificar);
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvRun = findViewById(R.id.tvRun);
                String run = tvRun.getText().toString();
                TextView tvDv = findViewById(R.id.tvDv);
                String dv = tvDv.getText().toString();
                TextView tvNombre = findViewById(R.id.tvNombre);
                String nombre = tvNombre.getText().toString();
                TextView tvFechaIngreso = findViewById(R.id.tvFechaIngereso);
                String fechaIngreso = tvFechaIngreso.getText().toString();
                Persona persona = new Persona(0, run,dv,nombre,fechaIngreso);
                //sql.actualizar(run, dv, nombre, fechaIngreso);
                CustomSql sql = new CustomSql(MainActivity.this, "miDB", null, 1);
                sql.actualizar(persona);
            }
        });




    }           ////  <<<  FIN  PROYECTO  >>>



    private void generarLista() {
        CustomSql sql = new CustomSql(MainActivity.this, "miDB", null, 1);
        ArrayList<Persona> todos = sql.todos();
        CustomAdapter adapter = new CustomAdapter(MainActivity.this, R.layout.item_layout_2, todos);
        ListView lvLista = findViewById(R.id.lvLista);
        lvLista.setAdapter(adapter);
    }
}

class CustomAdapter extends ArrayAdapter<Persona> {
    private Context miContexto;
    private int miRecurso;
    private ArrayList<Persona> miPersona;

    public CustomAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Persona> objects) {
        super(context, resource, objects);
        miContexto = context;
        miRecurso = resource;
        miPersona = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);


        View view = LayoutInflater.from(miContexto).inflate(miRecurso, null);
        TextView tvId2 = view.findViewById(R.id.tvIdSalida);
        TextView tvRun2 = view.findViewById(R.id.tvRunSalida);
        TextView tvDv2 = view.findViewById(R.id.tvDvSalida);
        TextView tvNombre2 = view.findViewById(R.id.tvNombreSalida);
        TextView tvFechaIngreso2 = view.findViewById(R.id.tvFechaIngresoSalida);
        ImageView ivBorrar = view.findViewById(R.id.ivBorrar);

        Persona item = miPersona.get(position);

        tvId2.setText(String.valueOf(item.getId()));
        tvRun2.setText(item.getRun());
        tvDv2.setText(item.getDv());
        tvNombre2.setText(item.getNombre());
        tvFechaIngreso2.setText(item.getFechaIngreso());

        ivBorrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(miContexto);
                builder.setTitle(R.string.Confirmacion);
                builder.setMessage(R.string.EliminarLista);
                builder.setPositiveButton(R.string.Aceptar, new DialogInterface.OnClickListener() {
                        @Override
                    public void onClick(DialogInterface dialog, int which) {
                        CustomAdapter.this.remove(item);                                      //elimina del adaptador
                        miPersona.remove(item);                                               //eliminar del arrayList

                        Persona persona = new Persona(0, "", "", "", "");
                        CustomSql sql = new CustomSql(MainActivity.this, "miDB", null, 1);
                        sql.delete(miPersona);
                    }
                }).setNegativeButton(R.string.Cancelar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });
        return view;
    }
}       //  FIN  CUSTOMADAPTER