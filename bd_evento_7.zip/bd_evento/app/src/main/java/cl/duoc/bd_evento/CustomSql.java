package cl.duoc.bd_evento;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;

import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class CustomSql extends SQLiteOpenHelper {

    private Context miContenxto;
    private String nombre;
    private int version;
    private SQLiteDatabase.CursorFactory factory;

    public CustomSql(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        miContenxto = context;
        nombre = name;
        this.version = version;
        this.factory = factory;
    }

    // CREACION de la Base de Datos
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "create table persona(id integer primary key autoincrement, run Text, dv Text, nombre Text, fechaIngreso Text)";
        db.execSQL(query);

    }

    // MODIFICAR
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    // INSERTAR
    public boolean insertar(Persona persona) {
        //escribir
        SQLiteDatabase escritor = this.getWritableDatabase();
        //los paramentros, lo que quiero insertar
        ContentValues cv = new ContentValues();

        cv.put("run", persona.getRun());
        cv.put("dv", persona.getDv());
        cv.put("nombre", persona.getNombre());
        cv.put("fechaIngreso", persona.getFechaIngreso());            // Ojo convertir de fecha a String.

        long respuesta = escritor.insertOrThrow("persona", null, cv); // insert into clase Persona(mensaje) values(Persona.getMensaje());
        escritor.close();
        return respuesta != -1;
        // return true;
    }

    public ArrayList<Persona> todos() {
        ArrayList<Persona> todos = new ArrayList<>();
        //escribir
        SQLiteDatabase escritor = this.getWritableDatabase();
        Cursor cursor = null;
        cursor = escritor.rawQuery("select  id, run, dv, nombre, fechaIngreso from persona", null);
        //pregunto si hay algo al comienzo
        if (cursor.moveToFirst()) {
            //recorro tupla por tupla
            do {
                int id = cursor.getInt(0);
                String run = cursor.getString(1);
                String dv = cursor.getString(2);
                String nombre = cursor.getString(3);
                String fechaIngreso = cursor.getString(4);
                Persona persona = new Persona(id, run, dv, nombre, fechaIngreso);   ////  REVUSAR
                todos.add(persona);
                //avanzo a la siguiente tupla
            } while (cursor.moveToNext());
        }
        escritor.close();
        return todos;
    }


// CLASE 15.... Buscar 1 registro, Update y Delete
    //Buscar
    public Persona buscar(String run)
    //public Persona buscar(int id)
    {
        Persona persona  = null; //lista:Lista = null
        SQLiteDatabase escritor = this.getWritableDatabase();
        Cursor cursor = null;
        String[] args = new String[] {String.valueOf(run)};
        // String[] args = new String[] {String.valueOf(id)};
        //cursor = escritor.rawQuery("select id,mensaje from lista where id  = ?",new String[] {String.valueOf(id)});
        cursor = escritor.rawQuery("select id, run, dv, nombre, fechaIngreso from persona where id  = ?",args);
        if(cursor.moveToFirst())
        {
            do {
                String runBuscar = cursor.getString(1);
                String dv = cursor.getString(2);
                String nombre = cursor.getString(3);
                String fechaIngreso = cursor.getString(4);
                ///////persona = new Persona(id, run, dv, nombre, fechaIngreso);

            }while (cursor.moveToNext());
        }
        escritor.close();
        return persona;
    }


    //Delete
    public boolean delete(ArrayList<Persona> id)
    {
        //escribir
        SQLiteDatabase escritor = this.getWritableDatabase();
        //los paramentros, lo que quiero insertar
        String[] args = new String[] {String.valueOf(id)};

        int respuesta = escritor.delete("persona","id=?",args); // delete lista where id = id);
        escritor.close();
        return respuesta != 0;

    }

    //Update
    public boolean actualizar(Persona persona)
    {
        //escribir
        SQLiteDatabase escritor = this.getWritableDatabase();
        //los paramentros, lo que quiero insertar
        ContentValues cv = new ContentValues();
        //cv.put("id",lista.getId()); el id se genera solo, no es necesario insertarlo
        cv.put("run",persona.getRun());
        cv.put("dv",persona.getDv());
        cv.put("nombre",persona.getNombre());
        cv.put("fechaIngreso",persona.getFechaIngreso());
        String[] args = new String[] {String.valueOf(persona.getId())};
        int respuesta = escritor.update("persona",cv,"id=?",args); // update lista set mensaje = lista.getMensaje() where id = lista.getId();
        escritor.close();
//        Log.i("respuesta__update",String.valueOf(respuesta));
        return respuesta != 0;

    }

}       //  FIN  CUSTOMSQL

